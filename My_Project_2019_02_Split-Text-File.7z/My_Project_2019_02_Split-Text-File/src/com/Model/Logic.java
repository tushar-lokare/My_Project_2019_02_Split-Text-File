package com.Model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.Scanner;

import com.pojo.Pojo;

public class Logic {

	public static void main(String[] args) {

		try {

			Pojo p = new Pojo();
			String s1 = p.getInputPath();
			String s2 = p.getOutputPath();
			String s3 = p.getSplitBy();

			String inputPath = s1.replace("\\", "\\\\");
			String destinationPath = s2.replace("\\", "\\\\")+"\\";
			int nol = Integer.parseInt(s3);

			File file = new File(inputPath);
			Scanner sc = new Scanner(file);

			int count = 0;
			while (sc.hasNextLine()) {
				sc.nextLine();
				count++;

			}

			double temp = (count / nol);
			int temp1 = (int) temp;
			int nof = 0;
			if (temp1 == temp) {
				nof = temp1;
			} else {
				nof = temp1 + 1;
			}
			
			FileInputStream fstream = new FileInputStream(inputPath);
			DataInputStream in = new DataInputStream(fstream);

			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;

			for (int j = 1; j <= nof; j++) {

				// location of new file
				FileWriter fstream1 = new FileWriter(destinationPath+ j + ".txt");
				BufferedWriter out = new BufferedWriter(fstream1);
				for (int i = 1; i <= nol; i++) {
					strLine = br.readLine();
					if (strLine != null) {
						out.write(strLine);
						if (i != nol) {
							out.newLine();
						}
					}
				}
				out.close();
			}

			in.close();
			
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}

	}

}
