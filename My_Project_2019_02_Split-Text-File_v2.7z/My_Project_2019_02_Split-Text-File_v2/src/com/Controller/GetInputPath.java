package com.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Model.Test;

/**
 * Servlet implementation class GetInputPath
 */
@WebServlet("/GetInputPath")
public class GetInputPath extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GetInputPath() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();

		String s1 = request.getParameter("inputPath");

		if (s1.equals(null)) {
			pw.println("Give input path first");
			pw.println("<br>" + "<hr>" + "<br>");
		} else {

			Test t1 = new Test();
			int c = t1.getCount(s1);

			pw.println("The number of lines in Input File: " + c);
			pw.println("<br>" + "<hr>" + "<br>");
		}

		RequestDispatcher rd = request.getRequestDispatcher("Index_v1.html");
		rd.include(request, response);

		String s2 = request.getParameter("destinationPath");
		String s3 = request.getParameter("splitBy");

		Test t1 = new Test();
		t1.SplitFiles(s1, s2, s3);

		Test tCount = new Test();
		int c = tCount.getCount(s1);
		int split = Integer.parseInt(s3);

		pw.println("File Split complete..." + "<br>");
	

	}
}
